
//import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileWriter;
import java.io.FileReader;

public class App {
    public static void main(String[] args) throws Exception {
        FileInputStream inFile = null;
        try {
            inFile = new FileInputStream(new File("entrada.txt"));
        } catch (IOException e) {
            System.err.println("Não foi possível abrir o arquivo de entrada\nSaindodo programa!");
            return;
        }

        FileOutputStream onFile = null;
        try {
            onFile = new FileOutputStream(new File("saida.txt"));
        } catch (IOException e) {
            System.err.println("Não foi possível abrir o arquivo de saida\nSaindodo programa!");
            return;
        }

        int c;

        String texto = "";
        char carac1 = '*';
        char carac2 = '_';
        int aux, aux1;
        aux = aux1 = 0;

        try {
            while ((c = inFile.read()) != -1) {
                if (carac1 == c && aux == 0) {
                    if (aux1 == 0) {
                        aux1++;
                        texto += "<b>";
                    } else {
                        aux1--;
                        texto += "</b>";
                    }
                } else if (carac2 == c && aux1 == 0) {
                    if (aux == 0) {
                        aux++;
                        texto += "<i>";
                    } else {
                        aux--;
                        texto += "</i>";
                    }
                }

                else if (Character.isWhitespace(c) || Character.isLetter(c)
                        || Character.getType(c) == Character.OTHER_PUNCTUATION) {
                    texto += (char) c;
                }
            }
            int i =0;
            for(; i< texto.length(); i++){
                //cp=texto.charAt(i);
                onFile.write((int)texto.charAt(i));
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler ou escrever no arquivo!");
        } finally {
            try {
               // BufferedWriter onFile = new BufferedWriter( onFile );
                System.out.println(texto);
                //onFile.write(texto);
                inFile.close();
                onFile.close();
            } catch (IOException e) {
                System.err.println("Erro ao fechar arquivos!");
            }
        }

    }
}
